# Écris un programme exo_18.rb qui va créer une liste de 50 faux emails et les stocker dans une array. 
# Voici le format que devront avoir les faux emails :

# "jean.dupont.01@email.fr"
# "jean.dupont.02@email.fr"
# etc..

emails = []

i = 1

while i < 10 do 
    emails << "jean.dupont.0#{i}@email.fr"
    i = i+1
end

while i >= 10 && i<=50 do 
    emails << "jean.dupont.#{i}@email.fr"
    i = i+1
end

puts emails.inspect


