# Écris un programme exo_12.rb qui demande un nombre à l'utilisateur, puis qui compte jusqu'à ce nombre.

puts "Choisis le nombre que tu veux !"
print "> "
n = Integer(gets.chomp)

i = 0

while i <= n  do
    puts i
i = i+1
end
