hello = "Bonjour, Monde !"
puts hello
# print "Et avec une voix sexy, ça donne : " + hello

# sert à insérer un commentaire et la ligne ne fait pas partie du code exécutable


