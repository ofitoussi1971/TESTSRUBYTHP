# Prends le programme exo_18.rb et créé un programme exo_19.rb qui va reprendre l'array des emails créés, 
# et n'afficher que les emails avec un nombre pair.

# "jean.dupont.02@email.fr"
# "jean.dupont.04@email.fr"
# etc..

emails = []

i = 2

while i < 10 do 
    emails << "jean.dupont.0#{i}@email.fr"
    i = i+2
end

while i >= 10 && i<=50 do 
    emails << "jean.dupont.#{i}@email.fr"
    i = i+2
end

puts emails.inspect