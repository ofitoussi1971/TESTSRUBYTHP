# Écris un programme exo_16.rb qui va demander son âge à l'utilisateur, et qui, pour chaque année depuis sa naissance, 
# dira "Il y a X ans, tu avais Y ans".


puts "Quelle est ton âge ?"
print "> "
n = Integer(gets.chomp)

current_year = 2020
birth_year = current_year - n

age1 = 0

while age1 <= n do
    puts "#{birth_year + age1} : Il y a #{n-age1} ans, tu avais: #{age1} ans"
    age1 = age1+1
end


