puts "Bonjour, c'est quoi ton blase ?"
user_name = gets.chomp
puts user_name

# gets.chomp récupère la valeur saisie dans l'invite du terminal en éliminant le retour chariot(\n) qu'exécute gets seul