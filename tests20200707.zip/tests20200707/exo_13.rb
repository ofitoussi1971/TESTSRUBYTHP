# Écris un programme exo_13.rb qui demande son année de naissance à l'utilisateur, 
# puis qui va ressortir chaque année depuis son année de naissance jusqu'aujourd'hui.

puts "Quelle est ton année de naissance ?"
print "> "
n = Integer(gets.chomp)

year = 2020

while n <= year do
    puts n
    n = n+1
end


