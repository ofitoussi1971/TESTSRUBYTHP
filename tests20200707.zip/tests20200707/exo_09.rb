# Écris un programme exo_09.rb qui demande le prénom de l'utilisateur, qui lui demande après son nom de famille, et qui salue l'utilisateur avec 
# "Bonjour, prénom nom !"


puts "Bonjour, c'est quoi ton prénom ?"
print "> "
user_name = gets.chomp
puts "Bonjour, c'est quoi ton nom de famille ?"
print "> "
user_surname = gets.chomp
puts "Bonjour, " + user_name + " " + user_surname + " ! "