hello = "Bonjour, Monde !"
puts hello
print "Et avec une voix sexy, ça donne : " + hello