# Rappel Exo 20 :
# Construis un programme exo_20.rb qui va demander à l'utilisateur un nombre entre 1 et 25 et qui va sortir une pyramide à descendre d' autant d'étages que ce nombre. Voici un exemple :

# Salut, bienvenue dans ma super pyramide ! Combien d'étages veux-tu ?
# > 5
# Voici la pyramide :
# #
# ##
# ###
# ####
# #####

# Exo 21 :
#Voici la pyramide :
#      #
#     ##
#    ###
#   ####
#  #####

puts "Salut, bienvenue dans ma super pyramide ! Combien d'étages veux-tu ?"
print "> "
n = Integer(gets.chomp)

i = 0
j = n

string = ""

puts "Voici la pyramide :"

while i < n do
    while j > 0 do
        string = string + " "
        j = j - 1
    end
    string = string + "#"
    puts string
    i = i+1
end

    
    
    
   
    