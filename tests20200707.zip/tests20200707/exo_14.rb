# Écris un programme exo_14.rb qui demande un nombre à l'utilisateur, 
# puis qui affiche un compte à rebours à partir de ce nombre, jusqu'à 0.

puts "Choisis un nombre !"
print "> "
n = Integer(gets.chomp)

while n >= 0 do
    puts n
    n = n-1
end


