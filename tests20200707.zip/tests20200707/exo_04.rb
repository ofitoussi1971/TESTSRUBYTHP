# puts "Salut, ça farte ?

# génère "unterminated string meets end of file" car il manque les guillements fermants