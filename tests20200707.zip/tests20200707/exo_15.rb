# Écris un programme exo_15.rb qui demande son année de naissance à l'utilisateur et qui va afficher chaque année 
# depuis son année de naissance jusqu'aujourd'hui. Pour chaque année affichée, le programme devra annoncer 
# l'âge que l'utilisateur avait cette année-là.


puts "Quelle est ton année de naissance ?"
print "> "
n = Integer(gets.chomp)
n1 = n
year = 2020


while n1 <= year do
    puts " #{n1} : #{n1-n} ans"
    n1 = n1+1
end


