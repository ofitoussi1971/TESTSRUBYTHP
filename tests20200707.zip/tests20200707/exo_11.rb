# Écris un programme exo_11.rb qui demande un nombre à l'utilisateur, puis qui écrit autant de fois "Salut, ça farte ?"

puts "Choisis le nombre que tu veux !"
print "> "
n = Integer(gets.chomp)

n.times do
    puts "Salut, ça farte ?"
end
