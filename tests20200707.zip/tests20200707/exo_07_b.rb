puts "Bonjour, c'est quoi ton blase ?"
print "> "
user_name = gets.chomp
puts user_name

# l'ajout de ">" par rapport à l'exo 7a matérialise le "prompt" pour l'utilisateur qui invisible sinon