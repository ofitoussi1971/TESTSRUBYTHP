# Écris un programme exo_10.rb qui demande son année de naissance à l'utilisateur, puis qui ressort l'âge que l'utilisateur a eu en 2017.

puts "Bonjour, quelle est ton année de naissance ?"
print "> "
user_year = Integer(gets.chomp)

puts "Votre âge en 2017 était : #{2017 - user_year} ans."
