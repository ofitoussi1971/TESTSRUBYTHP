# #{} permet d'insérer une expression et de retourner son résultat à l'intérieur d'une string

puts "On va compter le nombre d'heures de travail à THP" #imprime la string
puts "Travail : #{10 * 5 * 11}" #imprime la string en exécutant l'expression entre #{}
puts "En minutes ça fait : #{10 * 5 * 11 * 60}" #imprime la string en exécutant l'expression entre #{}

puts "Et en secondes ?" #imprime la string

puts 10 * 5 * 11 * 60 * 60 #pas de string donc exécute le calcul et retourne le résultat

puts "Est-ce que c'est vrai que 3 + 2 < 5 - 7 ?" #imprime la string

puts 3 + 2 < 5 - 7 #effectue le booléen et retourne true ou false

puts "Ça fait combien 3 + 2 ? #{3 + 2}" #imprime la string en exécutant l'expression entre #{}
puts "Ça fait combien 5 - 7 ? #{5 - 7}" #imprime la string en exécutant l'expression entre #{}

puts "Ok, c'est faux alors !" #imprime la string

puts "C'est drôle ça, faisons-en plus :" #imprime la string

puts "Est-ce que 5 est plus grand que -2 ? #{5 > -2}" #imprime la string en exécutant l'expression entre #{}
puts "Est-ce que 5 est supérieur ou égal à -2 ? #{5 >= -2}" #imprime la string en exécutant l'expression entre #{}
puts "Est-ce que 5 est inférieur ou égal à -2 ? #{5 <= -2}" #imprime la string en exécutant l'expression entre #{}