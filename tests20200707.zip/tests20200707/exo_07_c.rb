user_name = gets.chomp
puts user_name

# la différence entre les 3 programmes est la différence de compréhension pour l'utilisateur au niveau de ce qu'il doit faire,
# le programme b étant le plus claire et le c le moins clair